package ru.checkdev.auth.service;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Petr Arsentev (parsentev@yandex.ru)
 * @version $Id$
 * @since 0.1
 */
public class MessengerTest {

    @Test
    public void whenSend() {
        Map<String, String> keys = new HashMap<>();
        keys.put("key", "http");
    }
}