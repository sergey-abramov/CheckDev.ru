CREATE TABLE IF NOT EXISTS cd_filter (
user_id SERIAL PRIMARY KEY,
category_id INT,
topic_id INT
);