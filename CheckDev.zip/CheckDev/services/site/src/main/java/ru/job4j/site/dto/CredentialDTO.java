package ru.job4j.site.dto;

import lombok.Data;

@Data
public class CredentialDTO {
    private String email;
    private String password;
}
