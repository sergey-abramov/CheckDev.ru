--Скрипт добавляет поле status в таблицу interview
ALTER TABLE interview ADD COLUMN status INT DEFAULT 1;