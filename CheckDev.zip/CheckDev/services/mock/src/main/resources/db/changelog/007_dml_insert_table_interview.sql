INSERT INTO interview(type_interview, submitter_id, title, additional, contact_by, approximate_date, create_date, topic_id)
 VALUES ('2', '2', 'Первое знакомство со структурами данных', '', '@qwerty', '15:00', CURRENT_TIMESTAMP, '1');
INSERT INTO interview(type_interview, submitter_id, title, additional, contact_by, approximate_date, create_date, topic_id)
 VALUES ('1', '1', 'Структуры данных и алгоритмы', '', '@ytrewq', '16:00', CURRENT_TIMESTAMP, '1');