--Скрипт меняет в таблице interview в поле typeInterview  на mode
ALTER TABLE interview RENAME COLUMN type_interview TO mode;