![CI GitHubAction](https://github.com/peterarsentev/CheckDev/actions/workflows/maven.yml/badge.svg)


CheckDev - пробные собеседования в IT
