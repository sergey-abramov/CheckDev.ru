package ru.checkdev.desc.utility;

public class Utility {
    public static final int LIMIT_MOST_POPULAR = 5;
}
