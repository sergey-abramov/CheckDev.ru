UPDATE interview
SET topic_id = 1
WHERE topic_id IS NULL;