UPDATE interview SET create_date = '2023-10-10 12:44:18' WHERE id = 1;
UPDATE interview SET create_date = '2023-10-13 18:25:54' WHERE id = 2;
UPDATE interview SET title = 'Spring, Микросервисы', create_date = '2023-10-18 01:43:03' WHERE id = 3;
UPDATE interview SET title = 'Java Core, базовый синтаксис', create_date = '2023-10-26 10:23:54' WHERE id = 4;