INSERT INTO interview(type_interview, submitter_id, title, description, contact_by, approximate_date, create_date)
 VALUES ('2', '2', 'Первое знакомство со структурами данных', '', '@qwerty', '15:00', CURRENT_TIMESTAMP);
INSERT INTO interview(type_interview, submitter_id, title, description, contact_by, approximate_date, create_date)
 VALUES ('1', '1', 'Структуры данных и алгоритмы', '', '@ytrewq', '16:00', CURRENT_TIMESTAMP);