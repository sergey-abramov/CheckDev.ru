package ru.checkdev.notification.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Dmitry Stepanov, user Dmitry
 * @since 05.10.2023
 */
@Data
@AllArgsConstructor
public class RoleDTO {
    private int id;
}
